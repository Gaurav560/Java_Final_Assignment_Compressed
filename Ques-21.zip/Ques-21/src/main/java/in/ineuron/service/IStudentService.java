package in.ineuron.service;

import in.ineuron.bo.Student;

public interface IStudentService {

	public String insertDetails(Student student);
}
