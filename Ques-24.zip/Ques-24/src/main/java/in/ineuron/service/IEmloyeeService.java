package in.ineuron.service;

import in.ineuron.model.Employee;


public interface IEmloyeeService {

	public String saveDetails(Employee employee);
}
