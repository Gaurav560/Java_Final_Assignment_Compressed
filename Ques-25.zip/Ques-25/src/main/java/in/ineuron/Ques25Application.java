package in.ineuron;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ques25Application {

	public static void main(String[] args) {
		SpringApplication.run(Ques25Application.class, args);
	}

}
