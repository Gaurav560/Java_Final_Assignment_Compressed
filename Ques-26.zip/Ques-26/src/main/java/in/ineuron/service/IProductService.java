package in.ineuron.service;

import java.util.List;

import in.ineuron.model.Product;


public interface IProductService {

	public String saveDetails(Product product);//insert
	public List<Product> fetchAllProduct();//retrive all product
	public Product fetchProductById(Integer id);//retrive Product by id
	public String updateProductByDetails(Product product);//update 
	public String deleteProductById(Integer id);//delete





}
