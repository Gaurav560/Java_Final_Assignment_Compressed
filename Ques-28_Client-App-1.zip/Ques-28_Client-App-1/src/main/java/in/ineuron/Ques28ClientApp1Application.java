package in.ineuron;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ques28ClientApp1Application {

	public static void main(String[] args) {
		SpringApplication.run(Ques28ClientApp1Application.class, args);
	}

}
