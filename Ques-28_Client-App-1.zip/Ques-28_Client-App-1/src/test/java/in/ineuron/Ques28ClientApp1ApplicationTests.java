package in.ineuron;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ques28ClientApp1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
